package controller_board;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.Board;
import domain.Criteria;
import domain.Member;
import service.BoardService;
import utils.Const;

@WebServlet("/board/modify")
public class Modify extends HttpServlet{
	BoardService boardService = BoardService.getInstance(); 
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	 //로그인되었을때
		Long bno = Long.parseLong(req.getParameter("bno"));
		Member member = (Member)req.getSession().getAttribute("member");
		if (member == null || !member.getId().equals(boardService.get(bno).getWriter())) {
			resp.sendRedirect(req.getContextPath() + "/board/list");
		} else {
			req.setAttribute("board", boardService.get(bno));
			req.getRequestDispatcher(Const.board("modify")).forward(req, resp);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Criteria criteria = new Criteria();
		String title = req.getParameter("title");
		String content = req.getParameter("content");
		String bno = req.getParameter("bno");
		System.out.println(title);
		
		//pageNum
		criteria.setPageNum(Integer.parseInt(req.getParameter("pageNum")));
		//amount
		criteria.setAmount(Integer.parseInt(req.getParameter("amount")));
		//category
		criteria.setCategory(Integer.parseInt(req.getParameter("category")));

		
		Board board = new Board(Long.parseLong(bno), title, content, criteria.getCategory());
		
		boardService.modify(board);
		System.out.println(board);
		resp.sendRedirect("list" + criteria.getParams2());
	}
}
